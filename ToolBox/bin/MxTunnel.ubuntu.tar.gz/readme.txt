The MxTunnel is a Terminal (command line) program.
 
Copy MxTunnel to a location on your Linux computer, preferably to a
location that is in your PATH environment variable such as
/usr/local/bin.

e.g.
sudo cp MxTunnel /usr/local/bin

Type the following in a terminal window:
MxTunnel -help


See the following link for more information:
http://barracudaserver.com/products/BarracudaDrive/MxTunnel.lsp
